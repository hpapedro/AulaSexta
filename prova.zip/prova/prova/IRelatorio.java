package prova;

public interface IRelatorio {
    void gerar(String dados);
}

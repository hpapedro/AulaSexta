package prova;

public abstract class relatorioFactory {
    public abstract IRelatorio criarRelatorio();
    
}

